self.addEventListener('install', function(event) {
  console.log(event);
});